# `themer`

Your theme's unique URL:

https://themer.dev/?colors.dark.shade0=%2311110f&colors.dark.shade7=d9dad5&colors.dark.accent0=%239FA772&colors.dark.accent1=%23C2AC6A&colors.dark.accent2=%239A9A92&colors.dark.accent3=%23B3B7B0&colors.dark.accent4=%23C2BCB8&colors.dark.accent5=%23BBC2BA

If you find `themer` useful, here are some ways to support the project:

* Star [`themer` on GitHub](https://github.com/mjswensen/themer)
* Follow [@themerdev](https://twitter.com/themerdev) on Twitter
* [Send a tip through the Brave Browser](https://brave.com/the537), either on [the repository page](https://github.com/mjswensen/themer) or [the Web UI](https://themer.dev)
* Pay what you want when downloading your theme from [themer.dev](https://themer.dev)

# Installation instructions

## CSS

Import the generated theme file into your stylesheet via `@import()`, or into your HTML markup via `<link>`.

`hex.css` provides the theme colors in hex format; `rgb.css` and `hsl.css` in RGB and HSL formats respectively along with individual channel values for further manipulation if desired.

Generated files:

* `CSS/hex.css`
* `CSS/rgb.css`
* `CSS/hsl.css`